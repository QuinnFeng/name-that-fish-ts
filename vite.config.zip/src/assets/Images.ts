import salmon from "./salmon.jpeg";
import shark from "./shark.webp";
import trout from "./trout.jpeg";
import tuna from "./tuna.jpeg";

export const Images = {
    salmon,
    shark,
    trout,
    tuna,
};