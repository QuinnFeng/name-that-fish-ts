import { FunctionalGameBoard } from "./FunctionalGameBoard";
import { FunctionalScoreBoard } from "./FunctionalScoreBoard";
import { FunctionalFinalScore } from "./FunctionalFinalScore";
import { useState } from "react";

export function FunctionalApp() {
  const [counts,setCounts]= useState({counts:{correctCount:0,incorrectCount:0}});
  const [isCorrect,setIsCorrect]=useState<boolean|null>(null);
  const [isFinish,setIsFinish]=useState(false);

  function updateCounts(isCorrect:boolean){
    const prevCounts = counts.counts;
    const updatedCounts = isCorrect ? {
      ...prevCounts,
      correctCount: prevCounts.correctCount + 1,
    }
      : {
        ...prevCounts,
        incorrectCount: prevCounts.incorrectCount + 1,
      };
    setCounts({counts:updatedCounts});
    setIsCorrect(isCorrect);
  }

  return (
    <>
      {
        !isFinish?
        <>
          <FunctionalScoreBoard scoreBoardProps={{counts,isCorrect}}/>
          <FunctionalGameBoard 
              updateCounts = {(isCorrect: boolean) => updateCounts(isCorrect)}
              setIsFinish  = {(isFinish: boolean) => setIsFinish(isFinish)}
          />
        </>
        :
        <FunctionalFinalScore counts={counts} />
      }
    </>
  );
}
